Machine-Learning-Project-iNeuron
This is a project that is built using the Python and Flask Framework. This webapp can predict the overall score of a football player given various attributes and match information. This webapp is deployed on the Heroku Platform.

For more details :
https://www.youtube.com/watch?v=4b_X5FZTptk
https://github.com/thecuriousjuel/Machine-Learning-Project-iNeuron/blob/main/templates/output.html